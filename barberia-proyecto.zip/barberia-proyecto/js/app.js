// ============ Conexión directa a Firestore (REST simple, sin el SDK en tiempo real) ============
  const FIREBASE_PROJECT_ID = "navaja-dorada-e6a0d";
  const FIRESTORE_BASE = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/default/documents/site_data`;

  function fetchWithTimeout(url, options, ms){
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), ms);
    return fetch(url, { ...options, signal: controller.signal }).finally(() => clearTimeout(timer));
  }

  // ============ Almacenamiento compartido (Firestore vía REST) ============
  async function getShared(key, fallback){
    const t0 = performance.now();
    try{
      const res = await fetchWithTimeout(`${FIRESTORE_BASE}/${key}`, {}, 12000);
      if(res.status === 404){ console.log(`[Firestore] "${key}" no existe todavía, usando valor por defecto.`); return fallback; }
      if(!res.ok){ throw new Error(`HTTP ${res.status}`); }
      const data = await res.json();
      const raw = data && data.fields && data.fields.value && data.fields.value.stringValue;
      console.log(`[Firestore] leer "${key}": ${Math.round(performance.now()-t0)}ms`);
      if(raw === undefined) return fallback;
      const parsed = JSON.parse(raw);
      return (parsed === null || parsed === undefined) ? fallback : parsed;
    }catch(e){ console.error(`[Firestore] Error leyendo "${key}" tras ${Math.round(performance.now()-t0)}ms`, e); return fallback; }
  }
  async function setShared(key, value){
    if(value === null || value === undefined){
      console.error('Se intentó guardar un valor vacío en', key, '— cancelado para evitar corromper los datos.');
      throw new Error('Valor vacío, no se guardó nada.');
    }
    const t0 = performance.now();
    const payload = JSON.stringify(value);
    console.log(`[Firestore] guardando "${key}", tamaño: ${(payload.length/1024).toFixed(1)} KB`);
    try{
      const res = await fetchWithTimeout(`${FIRESTORE_BASE}/${key}?updateMask.fieldPaths=value`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fields: { value: { stringValue: payload } } })
      }, 15000);
      if(!res.ok){ const errBody = await res.text(); throw new Error(`HTTP ${res.status}: ${errBody}`); }
      console.log(`[Firestore] guardado "${key}": ${Math.round(performance.now()-t0)}ms`);
    }catch(e){ console.error(`[Firestore] Error guardando "${key}" tras ${Math.round(performance.now()-t0)}ms`, e); throw e; }
  }

  const THEMES = {
    dorado:  { label:'Negro y dorado',   bg:'#100d0a', bgAlt:'#181310', gold:'#c9a15a', burgundy:'#7a2f3d', cream:'#ede7dd' },
    azul:    { label:'Azul noche',       bg:'#0a0e14', bgAlt:'#111722', gold:'#4fb8e0', burgundy:'#2b4a73', cream:'#e7edf4' },
    verde:   { label:'Verde esmeralda',  bg:'#0b120e', bgAlt:'#131c16', gold:'#4caf7d', burgundy:'#2f5c46', cream:'#e6f0ea' },
    vino:    { label:'Vino tinto',       bg:'#150a0d', bgAlt:'#1e1014', gold:'#c9788a', burgundy:'#5c1a2b', cream:'#f0e3e6' },
    gris:    { label:'Gris moderno',     bg:'#111214', bgAlt:'#1a1b1e', gold:'#b0b6bd', burgundy:'#4a4f57', cream:'#eceef0' },
    claro:   { label:'Claro/beige',      bg:'#f5efe6', bgAlt:'#ece3d3', gold:'#a67c3d', burgundy:'#7a2f3d', cream:'#2a2118' }
  };

  // Utilidades de color: a partir de 5 colores base, calcula el resto de la paleta automáticamente
  function hexToRgb(hex){
    hex = (hex || '#000000').replace('#','');
    if(hex.length === 3) hex = hex.split('').map(c => c+c).join('');
    const num = parseInt(hex, 16) || 0;
    return { r:(num>>16)&255, g:(num>>8)&255, b:num&255 };
  }
  function rgbToHex(r,g,b){
    const c = v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2,'0');
    return '#' + c(r) + c(g) + c(b);
  }
  function blendHex(hexA, hexB, t){
    const a = hexToRgb(hexA), b = hexToRgb(hexB);
    return rgbToHex(a.r+(b.r-a.r)*t, a.g+(b.g-a.g)*t, a.b+(b.b-a.b)*t);
  }
  function hexToRgba(hex, alpha){
    const { r, g, b } = hexToRgb(hex);
    return `rgba(${r},${g},${b},${alpha})`;
  }
  function deriveTheme(base){
    return {
      bg: base.bg, bgAlt: base.bgAlt, gold: base.gold, burgundy: base.burgundy, cream: base.cream,
      card: blendHex(base.bgAlt, base.cream, 0.03),
      goldLight: blendHex(base.gold, '#ffffff', 0.25),
      muted: blendHex(base.cream, base.bg, 0.55),
      line: hexToRgba(base.gold, 0.2)
    };
  }
  function applyTheme(base){
    const t = deriveTheme(base || THEMES.dorado);
    const root = document.documentElement.style;
    root.setProperty('--bg', t.bg);
    root.setProperty('--bg-alt', t.bgAlt);
    root.setProperty('--card', t.card);
    root.setProperty('--gold', t.gold);
    root.setProperty('--gold-light', t.goldLight);
    root.setProperty('--burgundy', t.burgundy);
    root.setProperty('--cream', t.cream);
    root.setProperty('--muted', t.muted);
    root.setProperty('--line', t.line);
  }

  const DEFAULT_CONTENT = {
    shopName: 'La Navaja Dorada',
    theme: { bg:'#100d0a', bgAlt:'#181310', gold:'#c9a15a', burgundy:'#7a2f3d', cream:'#ede7dd' },
    pageTitle: 'La Navaja Dorada — Barbería',
    pageDescription: 'Reserva tu cita en La Navaja Dorada. Cortes clásicos, fade de precisión y arreglo de barba con navaja.',
    heroTitle: 'Cada corte se afila\ncon el mismo cuidado.',
    heroSubtitle: 'Cortes clásicos, fade de precisión y arreglo de barba con navaja. Reserva tu turno en menos de un minuto.',
    barberName: 'Rubén Alvarado',
    barberSpecialty: 'Fade, diseño y navaja clásica',
    barberBio: 'Más de 12 años de experiencia perfeccionando cortes clásicos y modernos, con especial atención al detalle en cada barba y acabado a navaja.',
    services: [
      {name:'Corte clásico', desc:'Tijera y máquina, acabado con navaja', price:180, slots:1},
      {name:'Fade / degradado', desc:'Alta precisión, líneas marcadas', price:220, slots:1},
      {name:'Arreglo de barba', desc:'Perfilado y navaja', price:150, slots:1},
      {name:'Corte + barba', desc:'El paquete completo', price:320, slots:2},
      {name:'Afeitado clásico', desc:'Navaja, toalla caliente, aceites', price:200, slots:1},
      {name:'Corte niño', desc:'Hasta 12 años', price:130, slots:1}
    ],
    address:'Av. Insurgentes Sur 1234, Col. Del Valle, CDMX',
    phone:'+52 55 1234 5678',
    hours:'Lun–Sáb, 10:00–20:00 · Dom cerrado',
    email:'hola@lanavajadorada.mx',
    whatsapp:'525512345678',
    facebookUrl:'',
    instagramUrl:'',
    waMessage:'Hola 👋, me gustaría agendar una cita en *{shop}* 💈✨. ¿Me podrían confirmar la disponibilidad?',
    barberPhoto:null,
    heroBackground:null,
    gallery:[
      {caption:'Fade clásico', image:null},
      {caption:'Barba tallada', image:null},
      {caption:'Pompadour', image:null},
      {caption:'Afeitado a navaja', image:null},
      {caption:'Corte texturizado', image:null},
      {caption:'Fade + diseño', image:null},
      {caption:'Corte niño', image:null},
      {caption:'Barba + bigote', image:null}
    ]
  };

  // Reduce y comprime una imagen antes de guardarla (las fotos se guardan como texto base64)
  function resizeImageFile(file, maxWidth=760, quality=0.72){
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          const scale = Math.min(1, maxWidth / img.width);
          const canvas = document.createElement('canvas');
          canvas.width = img.width * scale;
          canvas.height = img.height * scale;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL('image/jpeg', quality));
        };
        img.onerror = reject;
        img.src = reader.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  let content = null;
  let mediaDirty = false;

  function mergeContent(textPart, mediaPart){
    const t = textPart || {};
    const m = mediaPart || {};
    const baseGallery = t.gallery || DEFAULT_CONTENT.gallery;
    const galleryImages = m.galleryImages || baseGallery.map(g => g.image || null);
    const gallery = baseGallery.map((g, i) => ({ caption: g.caption, image: galleryImages[i] || null }));
    return {
      ...DEFAULT_CONTENT,
      ...t,
      gallery,
      barberPhoto: (m.barberPhoto !== undefined ? m.barberPhoto : t.barberPhoto) || null,
      heroBackground: (m.heroBackground !== undefined ? m.heroBackground : t.heroBackground) || null
    };
  }

  async function loadContent(){
    const [textPart, mediaPart] = await Promise.all([
      getShared('siteContent', null),
      getShared('siteMedia', null)
    ]);
    return mergeContent(textPart, mediaPart);
  }

  async function saveContent(c){
    const textPart = { ...c, gallery: c.gallery.map(g => ({ caption: g.caption })) };
    delete textPart.barberPhoto;
    delete textPart.heroBackground;
    const tasks = [ setShared('siteContent', textPart) ];
    if(mediaDirty){
      const mediaPart = { barberPhoto: c.barberPhoto, heroBackground: c.heroBackground, galleryImages: c.gallery.map(g => g.image) };
      tasks.push(setShared('siteMedia', mediaPart));
    }
    await Promise.all(tasks);
    mediaDirty = false;
  }
  let contentReadyResolve;
  const contentReady = new Promise(res => { contentReadyResolve = res; });

  function initials(name){
    return name.split(' ').filter(Boolean).slice(0,2).map(w=>w[0].toUpperCase()).join('');
  }

  function renderContent(){
    applyTheme(content.theme);
    document.getElementById('navLogo').innerHTML = content.shopName.replace(/(\w+)$/, '<span>$1</span>');
    document.title = content.pageTitle || content.shopName;
    const descTag = document.getElementById('pageDescTag');
    if(descTag) descTag.setAttribute('content', content.pageDescription || '');
    document.getElementById('heroTitle').innerHTML = content.heroTitle.replace(/\n/g,'<br>');
    document.getElementById('heroSubtitle').textContent = content.heroSubtitle;

    const heroSection = document.getElementById('heroSection');
    if(content.heroBackground){
      heroSection.classList.add('has-bg');
      heroSection.style.backgroundImage = `url(${content.heroBackground})`;
    }else{
      heroSection.classList.remove('has-bg');
      heroSection.style.backgroundImage = '';
    }
    document.getElementById('barberName').textContent = content.barberName;
    document.getElementById('barberSpecialty').textContent = content.barberSpecialty;
    document.getElementById('barberBio').textContent = content.barberBio;

    const barberAvatar = document.getElementById('barberAvatar');
    barberAvatar.innerHTML = content.barberPhoto
      ? `<img src="${content.barberPhoto}" alt="Foto de ${content.barberName}">`
      : `<span id="barberInitials">${initials(content.barberName)}</span>`;

    document.getElementById('cAddress').textContent = content.address;
    document.getElementById('cPhone').textContent = content.phone;
    document.getElementById('cPhoneLink').href = 'tel:' + content.phone.replace(/[^\d+]/g,'');
    document.getElementById('mapFrame').src = 'https://www.google.com/maps?q=' + encodeURIComponent(content.address) + '&output=embed';
    document.getElementById('cHours').textContent = content.hours;
    document.getElementById('cEmail').textContent = content.email;
    document.getElementById('footerName').textContent = content.shopName;

    const waMessage = encodeURIComponent((content.waMessage || DEFAULT_CONTENT.waMessage).replace('{shop}', content.shopName));
    const waLink = 'https://wa.me/' + content.whatsapp.replace(/\D/g,'') + '?text=' + waMessage;
    ['waHeroBtn','waNavBtn','waContactBtn','waFloatBtn'].forEach(id => document.getElementById(id).href = waLink);
    const fbLink = content.facebookUrl || '#';
    const igLink = content.instagramUrl || '#';
    document.getElementById('fbNavBtn').href = fbLink;
    document.getElementById('igNavBtn').href = igLink;
    document.getElementById('fbContactBtn').href = fbLink;
    document.getElementById('igContactBtn').href = igLink;
    document.getElementById('fbFloatBtn').href = fbLink;
    document.getElementById('igFloatBtn').href = igLink;

    const servicesList = document.getElementById('servicesList');
    servicesList.innerHTML = '';
    content.services.forEach(s => {
      const row = document.createElement('div');
      row.className = 'service-row';
      row.innerHTML = `<div><div class="name">${s.name}</div><div class="desc">${s.desc}</div></div><div class="price">$${s.price}</div>`;
      servicesList.appendChild(row);
    });

    const serviceSelect = document.getElementById('service');
    serviceSelect.innerHTML = '<option value="">Selecciona...</option>' + content.services.map(s => `<option value="${s.name}">${s.name} — $${s.price}</option>`).join('');

    const galleryGrid = document.getElementById('galleryGrid');
    galleryGrid.innerHTML = '';
    const tilePairs = [['#2a2117','#171310'],['#241f22','#14120f'],['#22201a','#171310'],['#251c1c','#14120f'],['#1f231d','#14120f'],['#241f18','#171310'],['#221c22','#14120f'],['#231f1a','#171310']];
    content.gallery.forEach((g,i) => {
      const [a,b] = tilePairs[i % tilePairs.length];
      const tile = document.createElement('div');
      tile.className = 'gallery-tile';
      tile.style.setProperty('--tile-a', a);
      tile.style.setProperty('--tile-b', b);
      tile.innerHTML = (g.image ? `<img src="${g.image}" alt="${g.caption}">` : '') + `<span>${g.caption}</span>`;
      if(g.image){
        tile.addEventListener('click', () => openLightbox(g.image, g.caption));
      }
      galleryGrid.appendChild(tile);
    });
  }

  // ============ Reservas ============
  // Horarios generados automáticamente: de 10:00 a 21:00 (9pm), citas de 45 minutos cada una
  function generateSlots(startHour, endHour, durationMin){
    const slots = [];
    let minutesFromMidnight = startHour * 60;
    const endMinutes = endHour * 60;
    while(minutesFromMidnight < endMinutes){
      const h = Math.floor(minutesFromMidnight / 60);
      const m = minutesFromMidnight % 60;
      slots.push(`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`);
      minutesFromMidnight += durationMin;
    }
    return slots;
  }
  const allSlots = ['10:00','10:45','11:30','12:15','13:00','13:45','14:30','15:15','16:00','16:45','17:30','18:15','19:00','19:45','20:30'];
  let selectedSlot = null;
  let bookingsCache = [];
  const dateInput = document.getElementById('date');
  dateInput.min = new Date().toISOString().split('T')[0];

  async function loadBookings(){ bookingsCache = await getShared('bookings', []); }

  function getServiceSlots(serviceName){
    const svc = content.services.find(s => s.name === serviceName);
    return (svc && svc.slots) || 1;
  }

  function occupiedTimesOf(b){
    const idx = allSlots.indexOf(b.time);
    if(idx === -1) return [b.time];
    return allSlots.slice(idx, idx + (b.slotsUsed || 1));
  }

  function isTimeOccupied(chosenDate, time){
    return bookingsCache.some(b => b.date === chosenDate && b.status !== 'cancelada' && occupiedTimesOf(b).includes(time));
  }

  function hasRoomFrom(chosenDate, startIdx, needed){
    if(startIdx + needed > allSlots.length) return false;
    for(let i = startIdx; i < startIdx + needed; i++){
      if(isTimeOccupied(chosenDate, allSlots[i])) return false;
    }
    return true;
  }

  function renderSlots(){
    const slotsEl = document.getElementById('slots');
    const slotMsg = document.getElementById('slotMsg');
    slotsEl.innerHTML = '';
    slotMsg.className = 'msg';
    slotMsg.textContent = '';
    const chosenDate = dateInput.value;

    if(!chosenDate){
      slotsEl.innerHTML = '<div class="empty-note" style="grid-column:1/-1;">Elige una fecha para ver los horarios.</div>';
      return;
    }

    const needed = getServiceSlots(document.getElementById('service').value);
    const isTaken = (time) => isTimeOccupied(chosenDate, time);
    const diaLleno = allSlots.every(isTaken);

    if(diaLleno){
      slotsEl.innerHTML = '<div class="empty-note" style="grid-column:1/-1;">Este día ya está lleno. Por favor elige otra fecha.</div>';
      slotMsg.className = 'msg error';
      slotMsg.textContent = 'No hay horarios disponibles para este día.';
      return;
    }

    allSlots.forEach((time, idx) => {
      const taken = !hasRoomFrom(chosenDate, idx, needed);
      const el = document.createElement('div');
      el.className = 'slot' + (taken ? ' disabled' : '') + (selectedSlot === time ? ' selected' : '');
      el.textContent = time;
      if(!taken){ el.addEventListener('click', () => { selectedSlot = time; renderSlots(); }); }
      slotsEl.appendChild(el);
    });

    if(needed > 1){
      slotMsg.className = 'msg';
      slotMsg.textContent = `Este servicio ocupa ${needed} turnos (${needed*45} min).`;
    }
  }
  dateInput.addEventListener('change', () => { selectedSlot = null; renderSlots(); });
  document.getElementById('service').addEventListener('change', () => { selectedSlot = null; renderSlots(); });

  function buildConfirmationWaLink(name, phone, service, date, time){
    const msg = `✨ *Nueva cita confirmada — ${content.shopName}* ✨\n\n👤 Cliente: ${name}\n📞 Teléfono: ${phone}\n💈 Servicio: ${service}\n📅 Fecha: ${date}\n🕒 Hora: ${time}\n\n¡Gracias por reservar, nos vemos pronto! 🙌`;
    return 'https://wa.me/' + content.whatsapp.replace(/\D/g,'') + '?text=' + encodeURIComponent(msg);
  }

  document.getElementById('bookingForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('name').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const service = document.getElementById('service').value;
    const date = dateInput.value;
    const slotMsg = document.getElementById('slotMsg');
    const formMsg = document.getElementById('formMsg');
    slotMsg.textContent = ''; formMsg.textContent = '';
    if(!date){ formMsg.className='msg error'; formMsg.textContent='Elige una fecha.'; return; }
    if(!selectedSlot){ slotMsg.className='msg error'; slotMsg.textContent='Elige un horario disponible.'; return; }

    await loadBookings();
    const needed = getServiceSlots(service);
    const startIdx = allSlots.indexOf(selectedSlot);
    const stillFree = hasRoomFrom(date, startIdx, needed);
    if(!stillFree){ slotMsg.className='msg error'; slotMsg.textContent='Ese horario ya no tiene suficiente espacio para este servicio, elige otro.'; renderSlots(); return; }

    const newBooking = { id: Date.now().toString(36), name, phone, service, barber: content.barberName, date, time: selectedSlot, slotsUsed: needed, status: 'pendiente' };
    bookingsCache.push(newBooking);
    await setShared('bookings', bookingsCache);

    const waLinkConfirm = buildConfirmationWaLink(name, phone, service, date, selectedSlot);

    document.getElementById('ticketBody').innerHTML = `
      <p>¡Listo, ${name}! Tu cita quedó registrada para el <strong class="mono">${date}</strong> a las <strong class="mono">${selectedSlot}</strong>. En breve te confirmamos.</p>
      <a href="${waLinkConfirm}" target="_blank" class="btn btn-wa" style="width:100%; justify-content:center; margin-top:16px;">
        <i class="fa-brands fa-whatsapp"></i> Avisar por WhatsApp
      </a>`;
    formMsg.className='msg ok'; formMsg.textContent = '¡Solicitud enviada! Te esperamos.';
    e.target.reset(); selectedSlot = null; renderSlots();

    // Abre WhatsApp automáticamente con el mensaje ya listo, justo al generarse la confirmación
    window.open(waLinkConfirm, '_blank');
  });

  // ============ Reseñas ============
  let selectedStars = 5;
  const starPicker = document.getElementById('starPicker');
  function paintStars(){ [...starPicker.children].forEach(i => i.classList.toggle('active', parseInt(i.dataset.v) <= selectedStars)); }
  starPicker.addEventListener('click', (e) => { if(e.target.dataset.v){ selectedStars = parseInt(e.target.dataset.v); paintStars(); } });
  paintStars();
  function starString(n){ return '★'.repeat(n) + '☆'.repeat(5-n); }

  let reviewsCache = [];
  async function renderReviews(){
    reviewsCache = await getShared('reviews', [
      {id:'seed1', name:'Marco A.', stars:5, comment:'Excelente atención, el fade quedó perfecto.', date:'2026-06-20'},
      {id:'seed2', name:'Diego R.', stars:5, comment:'Un artista con la navaja.', date:'2026-06-15'},
      {id:'seed3', name:'Luis F.', stars:4, comment:'Muy buen servicio, un poco de espera.', date:'2026-06-10'}
    ]);
    const list = document.getElementById('reviewList');
    list.innerHTML = '';
    reviewsCache.slice().reverse().forEach(r => {
      const el = document.createElement('div');
      el.className = 'review-card';
      el.innerHTML = `<div class="rh"><strong>${r.name}</strong><span class="stars">${starString(r.stars)}</span></div><p>${r.comment}</p><div class="rd">${r.date}</div>`;
      list.appendChild(el);
    });
    const avg = reviewsCache.length ? (reviewsCache.reduce((s,r)=>s+r.stars,0)/reviewsCache.length).toFixed(1) : '—';
    document.getElementById('ratingText').textContent = `${avg} de 5 · ${reviewsCache.length} reseñas`;
    document.getElementById('barberRatingText').textContent = `${avg} · ${reviewsCache.length} reseñas`;
  }

  document.getElementById('reviewForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('rName').value.trim();
    const comment = document.getElementById('rComment').value.trim();
    const msg = document.getElementById('reviewMsg');
    reviewsCache.push({ id: Date.now().toString(36), name, stars: selectedStars, comment, date: new Date().toISOString().split('T')[0] });
    await setShared('reviews', reviewsCache);
    msg.className = 'msg ok'; msg.textContent = '¡Gracias por tu reseña!';
    e.target.reset(); selectedStars = 5; paintStars();
    await renderReviews();
  });

  // ============ Panel del dueño (contraseña solo del lado del cliente, demo) ============
  const ADMIN_PASS = 'barberia2026';
  const adminOverlay = document.getElementById('adminOverlay');
  document.getElementById('openAdmin').addEventListener('click', () => adminOverlay.classList.add('open'));
  document.getElementById('closeAdmin').addEventListener('click', () => adminOverlay.classList.remove('open'));
  adminOverlay.addEventListener('click', (e) => { if(e.target === adminOverlay) adminOverlay.classList.remove('open'); });

  document.getElementById('adminLoginBtn').addEventListener('click', async () => {
    const pass = document.getElementById('adminPass').value;
    const msg = document.getElementById('adminLoginMsg');
    if(pass !== ADMIN_PASS){ msg.textContent = 'Contraseña incorrecta.'; return; }
    msg.textContent = '';
    document.getElementById('adminLogin').style.display = 'none';
    document.getElementById('adminContent').style.display = 'block';
    document.getElementById('tabContenido').innerHTML = '<div class="loading">Cargando datos...</div>';
    const t0 = performance.now();
    try{
      await contentReady;
      renderTabContenido();
      await loadBookings(); renderTabCitas();
      renderTabResenas();
      const secs = ((performance.now()-t0)/1000).toFixed(1);
      const note = document.createElement('div');
      note.style.cssText = 'color:var(--muted); font-size:.72rem; text-align:right; margin-top:-10px; margin-bottom:14px;';
      note.textContent = `Cargado en ${secs}s`;
      document.getElementById('tabContenido').prepend(note);
    }catch(err){
      console.error('Error abriendo el panel de edición', err);
      document.getElementById('tabContenido').innerHTML =
        `<div class="empty-note" style="color:#e08a8a;">Ocurrió un error al cargar el panel: ${err && err.message ? err.message : err}</div>`;
    }
  });

  document.querySelectorAll('.admin-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      ['contenido','citas','resenas'].forEach(t => document.getElementById('tab'+t[0].toUpperCase()+t.slice(1)).style.display = 'none');
      const el = document.getElementById('tab'+tab.dataset.tab[0].toUpperCase()+tab.dataset.tab.slice(1));
      el.style.display = 'block';
    });
  });

  function renderTabContenido(){
    const el = document.getElementById('tabContenido');
    el.innerHTML = `
      <fieldset><legend>Apariencia</legend>
        <div class="field">
          <label>Paquetes rápidos</label>
          <div class="theme-swatches" id="themeSwatches"></div>
        </div>
        <div class="field">
          <label>O ajusta los colores tú mismo</label>
          <div class="color-pickers" id="colorPickers"></div>
        </div>
      </fieldset>
      <fieldset><legend>Negocio</legend>
        <div class="field"><label>Nombre del negocio</label><input id="edShopName" value="${content.shopName}"></div>
        <div class="field"><label>Título de la pestaña del navegador (SEO)</label><input id="edPageTitle" value="${content.pageTitle || ''}" placeholder="Ej. La Navaja Dorada — Barbería"></div>
        <div class="field"><label>Descripción para buscadores como Google (SEO)</label><textarea id="edPageDescription" placeholder="Una o dos frases que describan tu barbería">${content.pageDescription || ''}</textarea></div>
        <div class="field"><label>Título del hero</label><textarea id="edHeroTitle">${content.heroTitle}</textarea></div>
        <div class="field"><label>Subtítulo del hero</label><textarea id="edHeroSubtitle">${content.heroSubtitle}</textarea></div>
        <div class="field">
          <label>Imagen de fondo del hero (opcional)</label>
          <div class="avatar-upload">
            <img class="thumb-lg" id="heroBgPreview" src="${content.heroBackground || ''}" style="${content.heroBackground ? '' : 'display:none;'}">
            <div>
              <label class="file-btn"><i class="fa-solid fa-upload"></i> Subir foto<input type="file" id="heroBgInput" accept="image/*"></label>
              <button type="button" class="btn btn-sm btn-danger" id="removeHeroBgBtn" style="margin-top:6px; ${content.heroBackground ? '' : 'display:none;'}">Quitar foto de fondo</button>
            </div>
          </div>
          <div class="msg" id="heroBgMsg"></div>
        </div>
      </fieldset>
      <fieldset><legend>Barbero</legend>
        <div class="field"><label>Nombre</label><input id="edBarberName" value="${content.barberName}"></div>
        <div class="field"><label>Especialidad</label><input id="edBarberSpecialty" value="${content.barberSpecialty}"></div>
        <div class="field"><label>Biografía</label><textarea id="edBarberBio">${content.barberBio}</textarea></div>
        <div class="field">
          <label>Foto del barbero</label>
          <div class="avatar-upload">
            <img class="thumb-lg" id="barberPhotoPreview" src="${content.barberPhoto || ''}" style="${content.barberPhoto ? '' : 'display:none;'}">
            <label class="file-btn"><i class="fa-solid fa-upload"></i> Subir foto<input type="file" id="barberPhotoInput" accept="image/*"></label>
          </div>
          <div class="msg" id="barberPhotoMsg"></div>
        </div>
      </fieldset>
      <fieldset><legend>Servicios</legend>
        <div id="svcEditor"></div>
        <button type="button" class="btn btn-sm btn-outline" id="addSvcBtn">+ Agregar servicio</button>
      </fieldset>
      <fieldset><legend>Galería (fotos de cortes)</legend>
        <div id="galEditor"></div>
        <button type="button" class="btn btn-sm btn-outline" id="addGalBtn">+ Agregar foto</button>
      </fieldset>
      <fieldset><legend>Contacto y redes</legend>
        <div class="field"><label>Dirección</label><input id="edAddress" value="${content.address}"></div>
        <div class="row2">
          <div class="field"><label>Teléfono mostrado</label><input id="edPhone" value="${content.phone}"></div>
          <div class="field"><label>WhatsApp (solo números, con código de país)</label><input id="edWhatsapp" value="${content.whatsapp}"></div>
        </div>
        <div class="row2">
          <div class="field"><label>Horario</label><input id="edHours" value="${content.hours}"></div>
          <div class="field"><label>Email</label><input id="edEmail" value="${content.email}"></div>
        </div>
        <div class="row2">
          <div class="field"><label>Link de Facebook</label><input id="edFacebook" value="${content.facebookUrl || ''}" placeholder="https://facebook.com/tu-pagina"></div>
          <div class="field"><label>Link de Instagram</label><input id="edInstagram" value="${content.instagramUrl || ''}" placeholder="https://instagram.com/tu-cuenta"></div>
        </div>
        <div class="field">
          <label>Mensaje que se prellena al escribir por WhatsApp (usa {shop} para el nombre del negocio)</label>
          <textarea id="edWaMessage">${content.waMessage || DEFAULT_CONTENT.waMessage}</textarea>
        </div>
      </fieldset>
      <button class="btn" id="saveContentBtn">Guardar cambios</button>
      <div class="msg" id="saveContentMsg"></div>`;

    document.getElementById('heroBgInput').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if(!file) return;
      const msg = document.getElementById('heroBgMsg');
      msg.textContent = 'Procesando imagen...';
      try{
        const dataUrl = await resizeImageFile(file, 1000, 0.6);
        content.heroBackground = dataUrl;
        mediaDirty = true;
        const preview = document.getElementById('heroBgPreview');
        preview.src = dataUrl; preview.style.display = 'block';
        document.getElementById('removeHeroBgBtn').style.display = 'inline-flex';
        msg.className='msg ok'; msg.textContent = 'Foto lista. Recuerda pulsar "Guardar cambios".';
      }catch(err){ msg.className='msg error'; msg.textContent = 'No se pudo procesar la imagen.'; }
    });
    document.getElementById('removeHeroBgBtn').addEventListener('click', () => {
      content.heroBackground = null;
      mediaDirty = true;
      document.getElementById('heroBgPreview').style.display = 'none';
      document.getElementById('removeHeroBgBtn').style.display = 'none';
      document.getElementById('heroBgMsg').textContent = 'Se quitará al guardar cambios.';
    });
    document.getElementById('barberPhotoInput').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if(!file) return;
      const msg = document.getElementById('barberPhotoMsg');
      msg.textContent = 'Procesando imagen...';
      try{
        const dataUrl = await resizeImageFile(file, 400, 0.7);
        content.barberPhoto = dataUrl;
        mediaDirty = true;
        const preview = document.getElementById('barberPhotoPreview');
        preview.src = dataUrl; preview.style.display = 'block';
        msg.className='msg ok'; msg.textContent = 'Foto lista. Recuerda pulsar "Guardar cambios".';
      }catch(err){ msg.className='msg error'; msg.textContent = 'No se pudo procesar la imagen.'; }
    });

    function renderThemeSwatches(){
      const wrap = document.getElementById('themeSwatches');
      wrap.innerHTML = '';
      Object.keys(THEMES).forEach(key => {
        const t = THEMES[key];
        const isActive = content.theme.bg === t.bg && content.theme.gold === t.gold && content.theme.cream === t.cream;
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'theme-swatch' + (isActive ? ' active' : '');
        btn.innerHTML = `<span class="dot" style="background:linear-gradient(135deg, ${t.gold}, ${t.bg})"></span><span>${t.label}</span>`;
        btn.addEventListener('click', () => {
          content.theme = { ...t };
          applyTheme(content.theme);
          renderThemeSwatches();
          renderColorPickers();
        });
        wrap.appendChild(btn);
      });
    }
    renderThemeSwatches();

    const COLOR_FIELDS = [
      { key:'bg', label:'Fondo' },
      { key:'bgAlt', label:'Fondo cajas' },
      { key:'gold', label:'Color principal' },
      { key:'burgundy', label:'Color secundario' },
      { key:'cream', label:'Texto' }
    ];
    function renderColorPickers(){
      const wrap = document.getElementById('colorPickers');
      wrap.innerHTML = '';
      COLOR_FIELDS.forEach(f => {
        const item = document.createElement('div');
        item.className = 'color-picker-item';
        item.innerHTML = `<input type="color" value="${content.theme[f.key]}" data-field="${f.key}"><span>${f.label}</span>`;
        wrap.appendChild(item);
      });
      wrap.querySelectorAll('input[type="color"]').forEach(inp => {
        inp.addEventListener('input', () => {
          content.theme[inp.dataset.field] = inp.value;
          applyTheme(content.theme);
          renderThemeSwatches();
        });
      });
    }
    renderColorPickers();

    function renderSvcRows(){
      const wrap = document.getElementById('svcEditor');
      wrap.innerHTML = '';
      content.services.forEach((s, i) => {
        const row = document.createElement('div');
        row.className = 'svc-editor-row';
        row.innerHTML = `
          <input data-i="${i}" data-f="name" value="${s.name}" placeholder="Nombre">
          <input data-i="${i}" data-f="desc" value="${s.desc}" placeholder="Descripción">
          <input data-i="${i}" data-f="price" type="number" value="${s.price}" placeholder="Precio">
          <input data-i="${i}" data-f="slots" type="number" min="1" max="4" value="${s.slots || 1}" title="Turnos de 45 min que ocupa" placeholder="Turnos">
          <button type="button" class="btn btn-sm btn-danger" data-remove="${i}"><i class="fa-solid fa-trash"></i></button>`;
        wrap.appendChild(row);
      });
      wrap.querySelectorAll('input').forEach(inp => {
        inp.addEventListener('input', () => {
          const i = parseInt(inp.dataset.i); const f = inp.dataset.f;
          content.services[i][f] = (f === 'price' || f === 'slots') ? (parseInt(inp.value)||1) : inp.value;
        });
      });
      wrap.querySelectorAll('button[data-remove]').forEach(btn => {
        btn.addEventListener('click', () => { content.services.splice(parseInt(btn.dataset.remove),1); renderSvcRows(); });
      });
    }
    renderSvcRows();
    document.getElementById('addSvcBtn').addEventListener('click', () => {
      content.services.push({name:'Nuevo servicio', desc:'', price:0, slots:1}); renderSvcRows();
    });

    function renderGalRows(){
      const wrap = document.getElementById('galEditor');
      wrap.innerHTML = '';
      content.gallery.forEach((g, i) => {
        const row = document.createElement('div');
        row.className = 'img-editor-row';
        row.innerHTML = `
          <img class="thumb" src="${g.image || ''}" style="${g.image ? '' : 'background:var(--bg-alt);'}">
          <div>
            <input type="text" data-i="${i}" data-f="caption" value="${g.caption}" placeholder="Descripción (ej. Fade clásico)">
            <label class="file-btn"><i class="fa-solid fa-upload"></i> Subir foto<input type="file" accept="image/*" data-i="${i}" class="galFileInput"></label>
            <div class="msg" data-gmsg="${i}"></div>
          </div>
          <button type="button" class="btn btn-sm btn-danger" data-remove="${i}"><i class="fa-solid fa-trash"></i></button>`;
        wrap.appendChild(row);
      });
      wrap.querySelectorAll('input[type="text"]').forEach(inp => {
        inp.addEventListener('input', () => { content.gallery[parseInt(inp.dataset.i)].caption = inp.value; });
      });
      wrap.querySelectorAll('.galFileInput').forEach(inp => {
        inp.addEventListener('change', async (e) => {
          const i = parseInt(inp.dataset.i);
          const file = e.target.files[0];
          if(!file) return;
          const msgEl = wrap.querySelector(`[data-gmsg="${i}"]`);
          msgEl.textContent = 'Procesando imagen...';
          try{
            const dataUrl = await resizeImageFile(file, 550, 0.65);
            content.gallery[i].image = dataUrl;
            mediaDirty = true;
            renderGalRows();
          }catch(err){ msgEl.className='msg error'; msgEl.textContent = 'No se pudo procesar la imagen.'; }
        });
      });
      wrap.querySelectorAll('button[data-remove]').forEach(btn => {
        btn.addEventListener('click', () => { content.gallery.splice(parseInt(btn.dataset.remove),1); mediaDirty = true; renderGalRows(); });
      });
    }
    renderGalRows();
    document.getElementById('addGalBtn').addEventListener('click', () => {
      content.gallery.push({caption:'Nueva foto', image:null}); mediaDirty = true; renderGalRows();
    });

    document.getElementById('saveContentBtn').addEventListener('click', async () => {
      content.shopName = document.getElementById('edShopName').value;
      content.pageTitle = document.getElementById('edPageTitle').value;
      content.pageDescription = document.getElementById('edPageDescription').value;
      content.heroTitle = document.getElementById('edHeroTitle').value;
      content.heroSubtitle = document.getElementById('edHeroSubtitle').value;
      content.barberName = document.getElementById('edBarberName').value;
      content.barberSpecialty = document.getElementById('edBarberSpecialty').value;
      content.barberBio = document.getElementById('edBarberBio').value;
      content.address = document.getElementById('edAddress').value;
      content.phone = document.getElementById('edPhone').value;
      content.whatsapp = document.getElementById('edWhatsapp').value;
      content.hours = document.getElementById('edHours').value;
      content.email = document.getElementById('edEmail').value;
      content.facebookUrl = document.getElementById('edFacebook').value;
      content.instagramUrl = document.getElementById('edInstagram').value;
      content.waMessage = document.getElementById('edWaMessage').value;
      const msg = document.getElementById('saveContentMsg');
      msg.className='msg'; msg.textContent='Guardando...';
      const tSave0 = performance.now();
      try{
        await saveContent(content);
        renderContent();
        const secs = ((performance.now()-tSave0)/1000).toFixed(1);
        msg.className='msg ok'; msg.textContent=`Cambios guardados y publicados (${secs}s).`;
      }catch(err){
        msg.className='msg error';
        msg.textContent = 'No se pudo guardar. Revisa que la base de datos de Firebase esté creada y con reglas que permitan escribir. Detalle: ' + (err && err.message ? err.message : err);
      }
    });
  }

  function renderTabCitas(){
    const el = document.getElementById('tabCitas');
    if(!bookingsCache.length){ el.innerHTML = '<div class="empty-note">Aún no hay citas reservadas.</div>'; return; }
    const sorted = [...bookingsCache].sort((a,b) => (a.date+a.time).localeCompare(b.date+b.time));
    el.innerHTML = '';
    sorted.forEach(b => {
      const row = document.createElement('div');
      row.className = 'admin-row';
      let actions = '';
      if(b.status === 'pendiente'){
        actions = `
          <button class="btn btn-sm" data-act="confirmar" data-id="${b.id}">Confirmar cita</button>
          <button class="btn btn-sm btn-danger" data-act="cancelar" data-id="${b.id}">Cancelar</button>`;
      }else if(b.status === 'confirmada'){
        actions = `
          <button class="btn btn-sm" data-act="completar" data-id="${b.id}">Marcar completada</button>
          <button class="btn btn-sm btn-danger" data-act="cancelar" data-id="${b.id}">Cancelar</button>`;
      }else{
        actions = `<button class="btn btn-sm btn-danger" data-act="eliminar" data-id="${b.id}">Eliminar</button>`;
      }
      row.innerHTML = `
        <div class="top-row"><strong>${b.name}</strong><span class="badge ${b.status}">${b.status}</span></div>
        <div>${b.service}</div>
        <div class="mono">${b.date} — ${b.time} · ${b.phone}</div>
        <div class="actions">${actions}</div>`;
      el.appendChild(row);
    });
    el.querySelectorAll('button[data-act]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const act = btn.dataset.act;
        if(act === 'eliminar'){
          bookingsCache = bookingsCache.filter(x => x.id !== btn.dataset.id);
        }else{
          const b = bookingsCache.find(x => x.id === btn.dataset.id);
          if(!b) return;
          if(act === 'confirmar') b.status = 'confirmada';
          else if(act === 'completar') b.status = 'completada';
          else if(act === 'cancelar') b.status = 'cancelada';
        }
        await setShared('bookings', bookingsCache);
        renderTabCitas(); renderSlots();
      });
    });
  }

  function renderTabResenas(){
    const el = document.getElementById('tabResenas');
    if(!reviewsCache.length){ el.innerHTML = '<div class="empty-note">Aún no hay reseñas.</div>'; return; }
    el.innerHTML = '';
    reviewsCache.slice().reverse().forEach(r => {
      const row = document.createElement('div');
      row.className = 'admin-row';
      row.innerHTML = `
        <div class="top-row"><strong>${r.name}</strong><span class="stars">${starString(r.stars)}</span></div>
        <div style="color:var(--muted);">${r.comment}</div>
        <div class="actions"><button class="btn btn-sm btn-danger" data-del="${r.id}">Eliminar</button></div>`;
      el.appendChild(row);
    });
    el.querySelectorAll('button[data-del]').forEach(btn => {
      btn.addEventListener('click', async () => {
        reviewsCache = reviewsCache.filter(r => r.id !== btn.dataset.del);
        await setShared('reviews', reviewsCache);
        renderTabResenas(); renderReviews();
      });
    });
  }

  // ============ Lightbox de galería ============
  const lightboxOverlay = document.getElementById('lightboxOverlay');
  function openLightbox(src, caption){
    document.getElementById('lightboxImg').src = src;
    document.getElementById('lightboxCaption').textContent = caption;
    lightboxOverlay.classList.add('open');
  }
  function closeLightbox(){ lightboxOverlay.classList.remove('open'); }
  lightboxOverlay.addEventListener('click', closeLightbox);
  document.getElementById('lightboxClose').addEventListener('click', (e) => { e.stopPropagation(); closeLightbox(); });

  // ============ Animación de aparición al hacer scroll ============
  function initReveal(){
    const targets = document.querySelectorAll('section > .section-head, section > .services, section > .barber-feature, section > .gallery, section > .reviews-wrap, section > .booking-wrap, section > .contact-wrap');
    targets.forEach(t => t.classList.add('reveal'));
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => { if(entry.isIntersecting){ entry.target.classList.add('visible'); io.unobserve(entry.target); } });
    }, { threshold: 0.12 });
    targets.forEach(t => io.observe(t));
  }

  // ============ Header transparente que se vuelve sólido al hacer scroll ============
  const headerEl = document.querySelector('header');
  function updateHeaderScroll(){ headerEl.classList.toggle('scrolled', window.scrollY > 40); }
  window.addEventListener('scroll', updateHeaderScroll);

  // ============ Instalar como app (PWA) ============
  if('serviceWorker' in navigator){
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('sw.js').catch((e) => console.warn('No se pudo registrar el service worker', e));
    });
  }
  let deferredInstallPrompt = null;
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredInstallPrompt = e;
    const btn = document.getElementById('installAppBtn');
    if(btn) btn.style.display = 'inline-flex';
  });
  document.addEventListener('click', (e) => {
    if(e.target && e.target.id === 'installAppBtn' && deferredInstallPrompt){
      deferredInstallPrompt.prompt();
      deferredInstallPrompt.userChoice.finally(() => { deferredInstallPrompt = null; });
    }
  });

  // ============ Inicialización ============
  (async () => {
    content = await loadContent();
    contentReadyResolve();
    renderContent();
    await loadBookings();
    renderSlots();
    await renderReviews();
    initReveal();
    updateHeaderScroll();
  })();
