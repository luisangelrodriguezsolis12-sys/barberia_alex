# La Navaja Dorada — Página de reservas

## Estructura del proyecto

```
barberia-proyecto/
├── index.html      → estructura de la página
├── css/
│   └── style.css   → todos los estilos (colores, tipografía, layout)
├── js/
│   └── app.js      → toda la lógica (reservas, reseñas, panel del dueño, imágenes)
└── README.md       → este archivo
```

## Cómo abrirlo en Visual Studio Code

1. Descomprime la carpeta `barberia-proyecto`.
2. Abre Visual Studio Code.
3. Ve a **Archivo → Abrir carpeta...** y selecciona la carpeta `barberia-proyecto`.
4. Para verla en el navegador, la forma más fácil es instalar la extensión **Live Server** (de Ritwick Dey) desde el ícono de extensiones en VS Code, y luego dar clic derecho sobre `index.html` → **Open with Live Server**.
   - Sin esa extensión también puedes abrir `index.html` directamente en tu navegador (doble clic), aunque algunas funciones dependen de que la página esté "servida" correctamente por un servidor local en vez de abierta como archivo suelto.

## Base de datos (Firebase Firestore)

Esta página ya está conectada a una base de datos real de Firebase (proyecto `navaja-dorada`), así que las citas, reseñas y el contenido editado se guardan de verdad, sin importar dónde subas la página (Vercel, GitHub Pages, etc.) — ya no depende de Claude.ai.

**Importante — seguridad de la base de datos:** ahora mismo la base de datos está en "modo de prueba", lo que significa que cualquiera con la configuración podría leer o escribir datos directamente (no solo a través de tu página). Esto es normal para empezar, pero antes de que tu barbería dependa de esto en serio, deberías:
1. Entrar a tu proyecto en [console.firebase.google.com](https://console.firebase.google.com)
2. Ir a Firestore Database → pestaña "Reglas"
3. Pedirle ayuda a Claude para escribir reglas de seguridad básicas (limitar tamaño de escritura, evitar borrado masivo, etc.)

**Límite a tener en cuenta:** cada documento de Firestore tiene un máximo de 1 MB. El contenido editable (incluyendo las fotos que subas) se guarda en un solo documento, así que si subes muchas fotos de alta resolución podrías acercarte a ese límite. Si eso pasa, avísale a Claude para dividir las imágenes en documentos separados.

## Próximos pasos recomendados

- Cambia la contraseña del panel de edición.
- Sube tus propias fotos del barbero y de la galería desde el panel "Editar página".
- Configura tu número real de WhatsApp y tus links de Facebook/Instagram.
